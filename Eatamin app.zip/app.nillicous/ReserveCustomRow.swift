//
//  ReserveCustomRow.swift
//  com.eatamin
//
//  Created by Ali Ghayeni on 12/27/16.
//  Copyright © 2016 ghayeni.ir. All rights reserved.
//

import Foundation
import UIKit

class ReserveCustomRow: UITableViewCell {
    

    
    
    @IBOutlet weak var labelReserveGuestCount: UILabel!
    @IBOutlet weak var labelReserveTime: UILabel!
    @IBOutlet weak var labelReserveDate: UILabel!
    @IBOutlet weak var labelReserveName: UILabel!
    @IBOutlet weak var labelReseveId: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
       
        
        
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
      
        
    }
    
}
