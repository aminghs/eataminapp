//
//  restaurantsMenuCustomRow2.swift
//  com.eatamin
//
//  Created by Ali Ghayeni on 8/17/16.
//  Copyright © 2016 ghayeni.ir. All rights reserved.
//

import Foundation
import UIKit

class restaurantsMenuCustomRow2: UITableViewCell {
    
    
    @IBOutlet weak var foodName: UILabel!
    @IBOutlet weak var foodPrice: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        
        
        
    }
    
    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // print(selected)
        // Configure the view for the selected state
        
        
    }
    
}
