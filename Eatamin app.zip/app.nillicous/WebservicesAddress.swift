//
//  WebservicesAddress.swift
//  app.nillicous
//
//  Created by Ali Ghayeni on 7/15/16.
//  Copyright © 2016 ghayeni.ir. All rights reserved.
//

import Foundation

var mainUrlThumb = "https://eatamin.com/adminpanel/files/"
var mainUrl = "https://eatamin.com/adminpanel/index.php/"
var newsUrl = "api/news"
var portFolioUrl = mainUrl+"api/portfolio"
var restaurantUrl = "api/restaurants"
var searchURL = "api/search"
var deliveryUrl = "api/delivering"
var setTokenUrl = ""//"api/token"//api/token
var setReserve = "api/reserve"
//api/token

//extension String {
//    
//    func replaceCharacters(characters: String, toSeparator: String) -> String {
//        let characterSet = NSCharacterSet(charactersInString: characters)
//        let components = self.componentsSeparatedByCharactersInSet(characterSet)
//        let result = components.joinWithSeparator("")
//        return result
//    }
//    
//    func wipeCharacters(characters: String) -> String {
//        return self.replaceCharacters(characters, toSeparator: "")
//    }
//}

