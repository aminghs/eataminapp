//
//  MyTabBarController.swift
//  com.eatamin
//
//  Created by Ali Ghayeni on 9/8/16.
//  Copyright © 2016 ghayeni.ir. All rights reserved.
//

import Foundation
import UIKit
class MyTabBarController: UITabBarController {
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
     //   self.tabBar.barTintColor = .blueColor()
     //   self.tabBar.backgroundColor = .greenColor()
        
}
}
